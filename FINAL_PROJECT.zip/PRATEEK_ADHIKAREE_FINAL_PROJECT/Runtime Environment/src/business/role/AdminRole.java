/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.role;

import business.Business;
import business.enterprise.Enterprise;
import business.organization.accounting.Accounting;
import business.useraccount.UserAccount;
import javax.swing.JPanel;
import userinterface.adminrole.AdminProfileJPanel;
import userinterface.adminrole.AdminRoleWorkAreaJPanel;

/**
 *
 * @author raseswaridas
 */
public class AdminRole extends Role {
    
    public void setSalary(){
        salary = 2000;
    }
    
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount userAccount, Enterprise enterprise, Business business){
        return new AdminRoleWorkAreaJPanel(userProcessContainer, userAccount, enterprise, business);
    }
    @Override
    public JPanel createProfile(JPanel userProcessContainer, UserAccount userAccount, Accounting accounting, Business business){
        return new AdminProfileJPanel(userProcessContainer, userAccount, accounting, business);
    }
    
}
